import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';

class Chat extends StatefulWidget {
  String name;
  String img;
  Chat({super.key, required this.name, required this.img});

  @override
  State<Chat> createState() => _ChatState();
}

class _ChatState extends State<Chat> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromARGB(255, 223, 219, 219),
      appBar: AppBar(
        title: Text(
          widget.name,
        ),
        leading: Padding(
          padding: const EdgeInsets.all(8.0),
          child: CircleAvatar(
            radius: 10,
            backgroundImage: NetworkImage(
              widget.img,
            ),
          ),
        ),
        actions: [
          Icon(
            Icons.call,
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Icon(Icons.video_call),
          )
        ],
        backgroundColor: Color.fromARGB(255, 40, 82, 42),
      ),
    );
  }
}
