import 'package:flutter/material.dart';
import 'package:uitask2/Model/user.dart';
import 'package:uitask2/view/chat.dart';

class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  List<Map<String, dynamic>> user = [
    {
      "name": "stella",
      "sub": "hey",
      "time": "4:00",
      "img": "https://pixlr.com/images/index/ai-image-generator-one.webp"
    },
    {
      "name": "arjun",
      "sub": "hey",
      "time": "4:00",
      "img":
          "https://www.simplilearn.com/ice9/free_resources_article_thumb/what_is_image_Processing.jpg"
    },
    {
      "name": "fluter group",
      "sub": "hey",
      "time": "4:00",
      "img":
          "https://www.shutterstock.com/image-photo/digital-technology-software-development-concept-600nw-2111828198.jpg"
    },
    {
      "name": "devan",
      "sub": "hey",
      "time": "4:00",
      "img":
          "https://www.simplilearn.com/ice9/free_resources_article_thumb/what_is_image_Processing.jpg"
    },
    {
      "name": "gopika",
      "sub": "hey",
      "time": "4:00",
      "img":
          "https://imgv3.fotor.com/images/slider-image/Female-portrait-picture-enhanced-with-better-clarity-and-higher-quality-using-Fotors-free-online-AI-photo-enhancer.jpg"
    },
    {
      "name": "developers group",
      "sub": "hey",
      "time": "4:00",
      "img":
          "https://www.shutterstock.com/image-photo/digital-technology-software-development-concept-600nw-2111828198.jpg"
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromARGB(255, 223, 219, 219),
      appBar: AppBar(
        backgroundColor: Color.fromARGB(255, 18, 71, 20),
        shadowColor: Color.fromARGB(255, 22, 67, 24),
        title: TextField(
          decoration: InputDecoration(
              prefixIcon: Icon(
                Icons.search,
                color: Colors.white,
              ),
              border:
                  OutlineInputBorder(borderRadius: BorderRadius.circular(20))),
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Icon(Icons.add),
          )
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
                itemCount: user.length,
                itemBuilder: ((context, index) {
                  return ListTile(
                    onTap: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => Chat(
                                    name: user[index]['name'],
                                    img: user[index]['img'],
                                  )));
                    },
                    title: Text(user[index]['name']),
                    leading: CircleAvatar(
                      backgroundImage: NetworkImage(user[index]['img']),
                    ),
                    trailing: Text(user[index]['time']),
                    subtitle: Text(user[index]['sub']),
                  );
                })),
          )
        ],
      ),
    );
  }
}
